Welcome to Webline, a mystery game through the format of a early 2000s blog site. 

To start the game, open "Weblinehome.html" you have no need to

(and are discouraged from!) open any other file. Doing so may

result in spoilers.


This game uses ciphers, hidden text, and downloadable images to

tell a story. You are encouraged to use outside resources to 

assist you. 


All characters and events are entirely fictional.


Welcome to the Webline.


Made by 
	Madeline S.
	Nox W.
	Daniel B. 